import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../widgets/app_main_bar.dart';
import '../widgets/post_card.dart';
import 'create_post_screen.dart';
import 'interest_matching_screen.dart';
import '../services/cache_service.dart';

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> with AutomaticKeepAliveClientMixin {
  final _supabase = Supabase.instance.client;
  final _cache = CacheService();
  late Future<List<Map<String, dynamic>>> _postsFuture;
  late Future<List<Map<String, dynamic>>> _resourcesFuture;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    _postsFuture = _fetchPosts();
    _resourcesFuture = _fetchResources();
  }

  Future<List<Map<String, dynamic>>> _fetchPosts() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return [];

    // Check cache first
    final cacheKey = 'posts_$userId';
    if (_cache.has(cacheKey)) {
      return _cache.get<List<Map<String, dynamic>>>(cacheKey) ?? [];
    }

    try {
      // Get friend IDs with caching
      final friendsCacheKey = 'friends_$userId';
      Set<String> friendIds;
      
      if (_cache.has(friendsCacheKey)) {
        friendIds = _cache.get<Set<String>>(friendsCacheKey) ?? {};
      } else {
        final friendsResponse = await _supabase
            .from('friendships')
            .select('user_id, friend_id')
            .eq('status', 'ACCEPTED')
            .or('user_id.eq.$userId,friend_id.eq.$userId');

        friendIds = <String>{};
        for (final row in friendsResponse as List) {
          if (row['user_id'] == userId) {
            friendIds.add(row['friend_id']);
          } else {
            friendIds.add(row['user_id']);
          }
        }
        _cache.set(friendsCacheKey, friendIds, durationMinutes: 10);
      }

      // Fetch posts
      final postsResponse = await _supabase
          .from('posts')
          .select('''
            *,
            author:users!author_id(id, full_name, avatar_url),
            post_media(id, media_url, media_type)
          ''')
          .order('created_at', ascending: false)
          .limit(50);

      final posts = List<Map<String, dynamic>>.from(postsResponse as List);

      // Filter based on visibility
      final filteredPosts = posts.where((post) {
        final visibility = post['visibility'];
        final authorId = post['author_id'];

        if (authorId == userId) return true;
        if (visibility == 'PUBLIC') return true;
        if (visibility == 'FRIENDS' && friendIds.contains(authorId)) return true;
        return false;
      }).toList();

      final postIds = filteredPosts.map((p) => p['id']).toList();
      if (postIds.isNotEmpty) {
        final likesResponse = await _supabase
            .from('post_likes')
            .select('post_id')
            .inFilter('post_id', postIds);
        
        final likesMap = <String, int>{};
        for (final like in likesResponse as List) {
          final postId = like['post_id'];
          likesMap[postId] = (likesMap[postId] ?? 0) + 1;
        }
        
        for (final post in filteredPosts) {
          post['likes_count'] = likesMap[post['id']] ?? 0;
        }
      }

      // Cache the result
      _cache.set(cacheKey, filteredPosts, durationMinutes: 3);
      return filteredPosts;
    } catch (e) {
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> _fetchResources() async {
    const cacheKey = 'resources_preview';
    
    if (_cache.has(cacheKey)) {
      return _cache.get<List<Map<String, dynamic>>>(cacheKey) ?? [];
    }

    try {
      final response = await _supabase
          .from('resources')
          .select('id, title, summary, cover_image_url')
          .order('created_at', ascending: false)
          .limit(3);

      final resources = List<Map<String, dynamic>>.from(response as List);
      _cache.set(cacheKey, resources, durationMinutes: 10);
      return resources;
    } catch (e) {
      return [];
    }
  }

  Future<void> _loadPosts() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId != null) {
      _cache.remove('posts_$userId');
    }
    setState(() {
      _loadData();
    });
  }

  Future<void> _navigateToCreatePost() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CreatePostScreen(),
      ),
    );

    if (result == true) {
      _loadPosts();
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;
    
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const AppMainBar(title: 'Home'),
      body: RefreshIndicator(
        onRefresh: _loadPosts,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Padding(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              child: Column(
                children: [
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const InterestMatchingScreen(),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF0EDFF),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                Icons.people,
                                color: const Color(0xFF6A5AE0),
                                size: isSmallScreen ? 28 : 32,
                              ),
                            ),
                            SizedBox(width: isSmallScreen ? 12 : 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Find Your Match',
                                    style: TextStyle(
                                      fontSize: isSmallScreen ? 16 : 18,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Connect with mentors who share your interests',
                                    style: TextStyle(
                                      fontSize: isSmallScreen ? 13 : 14,
                                      color: Colors.grey,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: isSmallScreen ? 12 : 16),
                  Container(
                    padding: EdgeInsets.all(isSmallScreen ? 16 : 20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF6A5AE0),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'Welcome to MkuluWanga',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 18 : 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Inter',
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Share your journey, find support, connect',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: isSmallScreen ? 13 : 14,
                            fontFamily: 'Inter',
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: isSmallScreen ? 12 : 16),
                        ElevatedButton.icon(
                          onPressed: _navigateToCreatePost,
                          icon: const Icon(Icons.add),
                          label: const Text('Create Post'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: const Color(0xFF6A5AE0),
                            padding: EdgeInsets.symmetric(
                              horizontal: isSmallScreen ? 20 : 24,
                              vertical: isSmallScreen ? 10 : 12,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: isSmallScreen ? 20 : 24),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Resources',
                      style: TextStyle(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  SizedBox(height: isSmallScreen ? 10 : 12),
                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: _resourcesFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: CircularProgressIndicator(),
                          ),
                        );
                      }

                      final resources = snapshot.data ?? [];
                      if (resources.isEmpty) {
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text(
                              'No resources available yet',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ),
                        );
                      }

                      return Column(
                        children: resources.map((resource) {
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: const Icon(
                                Icons.article,
                                color: Color(0xFF6A5AE0),
                              ),
                              title: Text(
                                resource['title'] ?? '',
                                style: TextStyle(
                                  fontFamily: 'Inter',
                                  fontSize: isSmallScreen ? 14 : 15,
                                ),
                              ),
                              subtitle: Text(
                                resource['summary'] ?? '',
                                style: TextStyle(
                                  fontFamily: 'Inter',
                                  fontSize: isSmallScreen ? 12 : 13,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                  SizedBox(height: isSmallScreen ? 20 : 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Community Posts',
                        style: TextStyle(
                          fontSize: isSmallScreen ? 16 : 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Inter',
                        ),
                      ),
                      TextButton.icon(
                        onPressed: _loadPosts,
                        icon: const Icon(Icons.refresh, size: 18),
                        label: const Text('Refresh'),
                      ),
                    ],
                  ),
                  SizedBox(height: isSmallScreen ? 10 : 12),
                ],
              ),
            ),
            
            FutureBuilder<List<Map<String, dynamic>>>(
              future: _postsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: CircularProgressIndicator(),
                    ),
                  );
                }

                if (snapshot.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          'Error loading posts: ${snapshot.error}',
                          style: const TextStyle(color: Colors.red),
                        ),
                      ),
                    ),
                  );
                }

                final posts = snapshot.data ?? [];
                if (posts.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Column(
                          children: [
                            Icon(
                              Icons.post_add,
                              size: 48,
                              color: Colors.grey[400],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No posts yet',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[600],
                                fontFamily: 'Inter',
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Be the first to share something!',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[500],
                                fontFamily: 'Inter',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }

                return Column(
                  children: posts.map((post) {
                    return PostCard(
                      post: post,
                      onLikeChanged: _loadPosts,
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToCreatePost,
        backgroundColor: const Color(0xFF6A5AE0),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
